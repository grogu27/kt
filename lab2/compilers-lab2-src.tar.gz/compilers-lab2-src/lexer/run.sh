#!/bin/sh

./driver ./prog.pas
