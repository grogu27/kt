#!/bin/sh

git clone https://github.com/facebook/folly
